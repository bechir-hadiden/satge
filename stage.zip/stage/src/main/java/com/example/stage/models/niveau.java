package com.example.stage.models;

import java.io.Serializable;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;



@Entity 
@Table(name = "niveau")
public class niveau implements Serializable  {
	
	@Id
	public String niveau ;

	public niveau(String niveau) {
		super();
		this.niveau = niveau;
	}

	public String getNiveau() {
		return niveau;
	}

	public void setNiveau(String niveau) {
		this.niveau = niveau;
	} 
	
	
	

}
